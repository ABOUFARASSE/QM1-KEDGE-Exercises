Editable XeLaTeX source for 28 QM1 academic PDFs. Run xelatex twice per .tex file. Figures are vector PDF assets. All documents reflect the bilingual October 2026 curriculum.
